
function send(message) { return new Promise(res => chrome.runtime.sendMessage(message, res)); }

async function refresh() {
  const counts = await send({ type: "getCounts" });
  document.getElementById("total").textContent = `Blocked this session: ${counts.total || 0}`;
  const list = document.getElementById("domains");
  list.innerHTML = "";
  const entries = Object.entries(counts.byDomain || {}).sort((a,b)=>b[1]-a[1]).slice(0, 20);
  if (entries.length === 0) {
    list.textContent = "No trackers blocked yet.";
    return;
  }
  entries.forEach(([d, c]) => {
    const div = document.createElement("div");
    div.className = "row";
    div.innerHTML = `<span>${d}</span><span>${c}</span>`;
    list.appendChild(div);
  });
}

document.getElementById("resetBtn").addEventListener("click", async () => {
  await send({ type: "resetCounts" });
  await refresh();
});

document.getElementById("whitelistBtn").addEventListener("click", async () => {
  const res = await send({ type: "whitelistThisSite" });
  await refresh();
  alert(res?.ok ? `Whitelisted: ${res.added}` : `Error: ${res.error}`);
});

document.getElementById("openOptions").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

refresh();
