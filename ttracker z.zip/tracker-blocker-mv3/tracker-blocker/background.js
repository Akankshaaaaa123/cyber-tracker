// background.js

// Keep count of blocked requests per tab
let blockedCounts = {};

// Listen for rule matches (when a tracker is blocked)
chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
  const tabId = info.tabId;

  if (tabId >= 0) {
    // Increase counter for this tab
    blockedCounts[tabId] = (blockedCounts[tabId] || 0) + 1;

    // Update badge text
    chrome.action.setBadgeText({ tabId: tabId, text: String(blockedCounts[tabId]) });
    chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: "red" });
  }
});

// Reset counter when a new page loads
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    blockedCounts[tabId] = 0;
    chrome.action.setBadgeText({ tabId: tabId, text: "" });
  }
});

// Clean up when a tab is closed
chrome.tabs.onRemoved.addListener((tabId) => {
  delete blockedCounts[tabId];
});
