
function send(message) { return new Promise(res => chrome.runtime.sendMessage(message, res)); }

function textToList(t) {
  return t.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
}
function listToText(list) {
  return (list || []).join("\n");
}

async function load() {
  const settings = await send({ type: "getSettings" });
  document.getElementById("whitelist").value = listToText(settings.whitelist);
  document.getElementById("blacklist").value = listToText(settings.blacklist);
}

document.getElementById("save").addEventListener("click", async () => {
  const s = {
    whitelist: textToList(document.getElementById("whitelist").value),
    blacklist: textToList(document.getElementById("blacklist").value)
  };
  const res = await send({ type: "setSettings", settings: s });
  alert(res?.ok ? "Saved!" : "Failed to save.");
});

document.getElementById("reset").addEventListener("click", async () => {
  const s = { whitelist: [], blacklist: [] };
  const res = await send({ type: "setSettings", settings: s });
  await load();
  alert(res?.ok ? "Reset!" : "Failed to reset.");
});

load();
